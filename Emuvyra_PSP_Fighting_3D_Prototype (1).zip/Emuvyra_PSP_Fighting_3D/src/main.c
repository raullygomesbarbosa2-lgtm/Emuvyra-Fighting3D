/*
 * Emuvyra PSP Fighting — PSP GU 3D scene prototype
 * Requires PSPSDK. This source has not been compiled/tested in this environment.
 * Original GLB is preserved in assets/, but GLB loading/conversion is not implemented yet.
 */
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <pspgum.h>
#include <pspctrl.h>
#include <pspdebug.h>
#include <math.h>
#include <string.h>

PSP_MODULE_INFO("EmuvyraFighting3D", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define BUF_WIDTH 512
#define SCR_WIDTH 480
#define SCR_HEIGHT 272
#define LIST_SIZE (256 * 1024)

static unsigned int __attribute__((aligned(16))) list[LIST_SIZE / 4];
static unsigned short __attribute__((aligned(16))) fb0[BUF_WIDTH * SCR_HEIGHT];
static unsigned short __attribute__((aligned(16))) fb1[BUF_WIDTH * SCR_HEIGHT];
static unsigned int __attribute__((aligned(16))) zbuf[BUF_WIDTH * SCR_HEIGHT];

typedef struct { float x,y,z; unsigned int color; } Vertex;
typedef struct {
    float x,z,yaw;
    int hp, guard, action, frames;
    float cooldown;
} Fighter;

static Fighter player = { -0.7f, 1.0f, 0.0f, 100, 0, 0, 0, 0.0f };
static Fighter cpu    = {  0.7f,-1.0f, 3.14159f,100, 0, 0, 0, 0.4f };

static void setup_gu(void) {
    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_5650, (void*)0, BUF_WIDTH);
    sceGuDispBuffer(SCR_WIDTH, SCR_HEIGHT, fb0, BUF_WIDTH);
    sceGuDepthBuffer(zbuf, BUF_WIDTH);
    sceGuOffset(2048 - (SCR_WIDTH/2), 2048 - (SCR_HEIGHT/2));
    sceGuViewport(2048, 2048, SCR_WIDTH, SCR_HEIGHT);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, SCR_WIDTH, SCR_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuEnable(GU_DEPTH_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuFrontFace(GU_CW);
    sceGuEnable(GU_CULL_FACE);
    sceGuShadeModel(GU_SMOOTH);
    sceGuEnable(GU_CLIP_PLANES);
    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

static void draw_box(float x,float y,float z,float sx,float sy,float sz,unsigned int c) {
    /* Immediate colored cuboid; used only for arena/blockout prototype. */
    sceGumPushMatrix();
    ScePspFVector3 pos = {x,y,z};
    ScePspFVector3 scale = {sx,sy,sz};
    sceGumTranslate(&pos);
    sceGumScale(&scale);
    sceGuColor(c);
    static const float v[] = {
      -.5f,-.5f,-.5f,  .5f,-.5f,-.5f,  .5f,.5f,-.5f,
      -.5f,-.5f,-.5f,  .5f,.5f,-.5f, -.5f,.5f,-.5f,
      -.5f,-.5f,.5f,  .5f,.5f,.5f,  .5f,-.5f,.5f,
      -.5f,-.5f,.5f, -.5f,.5f,.5f,  .5f,.5f,.5f,
      -.5f,-.5f,-.5f, -.5f,-.5f,.5f, .5f,-.5f,.5f,
      -.5f,-.5f,-.5f, .5f,-.5f,.5f, .5f,-.5f,-.5f,
      -.5f,.5f,-.5f, .5f,.5f,.5f, -.5f,.5f,.5f,
      -.5f,.5f,-.5f, .5f,.5f,-.5f, .5f,.5f,.5f,
      -.5f,-.5f,-.5f, -.5f,.5f,.5f, -.5f,-.5f,.5f,
      -.5f,-.5f,-.5f, -.5f,.5f,-.5f, -.5f,.5f,.5f,
      .5f,-.5f,-.5f, .5f,-.5f,.5f, .5f,.5f,.5f,
      .5f,-.5f,-.5f, .5f,.5f,.5f, .5f,.5f,-.5f
    };
    sceGumDrawArray(GU_TRIANGLES, GU_VERTEX_32BITF|GU_TRANSFORM_3D,
                    36, 0, v);
    sceGumPopMatrix();
}

static void draw_fighter_blockout(Fighter *f, unsigned int color) {
    /* Temporary geometry only. Replace with converted original GLB at integration stage. */
    float lean = f->action == 1 ? 0.18f : (f->action == 2 ? -0.10f : 0.0f);
    draw_box(f->x,0.68f+lean,f->z,0.38f,0.65f,0.22f,color);          /* torso */
    draw_box(f->x,1.13f+lean,f->z,0.25f,0.25f,0.24f,0xFFE0C0FF);     /* head */
    draw_box(f->x-0.30f,0.70f+lean,f->z,0.13f,0.42f,0.14f,color);    /* left arm */
    draw_box(f->x+0.30f,0.70f+lean,f->z,0.13f,0.42f,0.14f,color);   /* right arm */
    draw_box(f->x-0.13f,0.20f,f->z,0.14f,0.48f,0.16f,color);        /* left leg */
    draw_box(f->x+0.13f,0.20f,f->z,0.14f,0.48f,0.16f,color);        /* right leg */
    if (f->action == 1) draw_box(f->x+0.43f,0.82f,f->z-0.10f,0.20f,0.13f,0.15f,0xFF2020FF);
    if (f->action == 2) draw_box(f->x+0.30f,0.30f,f->z-0.35f,0.15f,0.16f,0.38f,0xFF2020FF);
}

static void render_scene(void) {
    sceGuStart(GU_DIRECT, list);
    sceGuClearColor(0xFF19100A);
    sceGuClearDepth(0);
    sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);

    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(55.0f, 16.0f/9.0f, 0.5f, 100.0f);

    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    ScePspFVector3 cam = {0.0f, 3.1f, 6.7f};
    ScePspFVector3 at  = {0.0f, 0.45f, 0.0f};
    ScePspFVector3 up  = {0.0f, 1.0f, 0.0f};
    sceGumLookAt(&cam,&at,&up);

    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();

    /* Ring floor and boundary ropes. */
    draw_box(0.0f,-0.13f,0.0f,5.5f,0.20f,5.5f,0xFF4B4B4B);
    draw_box(0.0f,0.02f,0.0f,4.8f,0.04f,4.8f,0xFF303060);
    for (int i=0;i<4;i++) {
        float y = 0.45f + 0.32f*i;
        draw_box(0.0f,y,-2.35f,4.8f,0.035f,0.035f,0xFFE0E0E0);
        draw_box(0.0f,y, 2.35f,4.8f,0.035f,0.035f,0xFFE0E0E0);
        draw_box(-2.35f,y,0.0f,0.035f,0.035f,4.8f,0xFFE0E0E0);
        draw_box( 2.35f,y,0.0f,0.035f,0.035f,4.8f,0xFFE0E0E0);
    }
    draw_fighter_blockout(&player,0xFF3C3CDA);
    draw_fighter_blockout(&cpu,0xFF3030D0);

    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

static void start_action(Fighter *f,int action,int frames) { f->action=action; f->frames=frames; }
static void update_fighter(Fighter *f) { if(f->frames>0 && --f->frames==0) f->action=0; }

static void update_game(SceCtrlData *pad) {
    if (pad->Lx < 90) player.x -= 0.035f;
    if (pad->Lx > 165) player.x += 0.035f;
    if (pad->Ly < 90) player.z -= 0.035f;
    if (pad->Ly > 165) player.z += 0.035f;
    if (player.x < -1.8f) player.x=-1.8f;
    if (player.x >  1.8f) player.x= 1.8f;
    if (player.z < -1.8f) player.z=-1.8f;
    if (player.z >  1.8f) player.z= 1.8f;
    player.guard = (pad->Buttons & PSP_CTRL_SQUARE) != 0;
    if (player.action==0) {
        if (pad->Buttons & PSP_CTRL_CROSS) start_action(&player,1,16);
        else if (pad->Buttons & PSP_CTRL_CIRCLE) start_action(&player,2,24);
        else if (pad->Buttons & PSP_CTRL_TRIANGLE) start_action(&player,3,30);
    }
    cpu.cooldown -= 1.0f/60.0f;
    float dx=player.x-cpu.x, dz=player.z-cpu.z;
    if (cpu.cooldown<=0.0f && cpu.action==0) {
        if (dx*dx+dz*dz > 1.1f) {
            cpu.x += (dx>0?1:-1)*0.012f;
            cpu.z += (dz>0?1:-1)*0.018f;
        } else {
            start_action(&cpu, (cpu.cooldown < -1.0f)?2:1, 22);
            cpu.cooldown=1.1f;
        }
    }
    if (player.action==1 && player.frames==1 && dx*dx+dz*dz<1.1f) cpu.hp -= 7;
    if (player.action==2 && player.frames==1 && dx*dx+dz*dz<1.4f) cpu.hp -= 12;
    if (player.action==3 && player.frames==1 && dx*dx+dz*dz<1.5f) cpu.hp -= 18;
    if (cpu.hp<0) cpu.hp=0;
    update_fighter(&player);
    update_fighter(&cpu);
}

int main(void) {
    setup_gu();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    SceCtrlData pad;
    unsigned int old=0;
    for (;;) {
        sceCtrlReadBufferPositive(&pad,1);
        unsigned int pressed=pad.Buttons & ~old; old=pad.Buttons;
        if (pressed & PSP_CTRL_START) break;
        update_game(&pad);
        render_scene();
    }
    sceGuTerm();
    sceKernelExitGame();
    return 0;
}
