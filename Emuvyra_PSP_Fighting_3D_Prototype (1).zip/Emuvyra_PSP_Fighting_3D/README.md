# Emuvyra Fighting 3D — protótipo PSP

**Status honesto:** código-fonte de protótipo; ainda não é uma ISO nem um jogo completo. O ambiente de trabalho atual não possui PSPSDK/`psp-gcc`, então a compilação não foi executada localmente.

## Conteúdo
- Cena 3D inicial usando PSP GU: ringue e personagens geométricos temporários.
- Controles previstos: analógico, X (soco), O (chute), Triângulo (ataque forte), Quadrado (defesa) e Start (sair).
- Lógica inicial de aproximação e ataque do adversário CPU.
- Modelo `assets/personagem_animado_prisma3d.glb` guardado sem alterações; ainda não aparece no jogo.
- GitHub Actions para compilar `EBOOT.PBP` usando PSPSDK em pushes para `main`/`master` ou manualmente pela aba Actions.

## Como obter o primeiro build
1. Envie os arquivos do projeto para um repositório GitHub.
2. Abra a aba **Actions** e execute **Build PSP homebrew**, ou faça push para `main`/`master`.
3. Se a compilação passar, baixe o artefato `EmuvyraFighting3D-EBOOT` daquela execução. O artefato é um `EBOOT.PBP`, não uma ISO.

## O que ainda falta
- A compilação e o funcionamento ainda precisam ser verificados em execução real do workflow e no PPSSPP/PSP.
- O lutador original não é carregado pelo protótipo. PSP não lê GLB diretamente; é necessário converter malha, materiais e texturas e implementar um carregador compatível. A aparência do GLB original foi preservada no arquivo incluído.
- Faltam esqueleto/animações integrados, colisões confiáveis, dano/defesa completos, barra de vida e HUD, menus, áudio, tela de vitória/derrota e testes.
- Uma ISO de PSP exige uma estrutura de disco/empacotamento adequada. Só faz sentido produzi-la depois de existir um build funcional e validado. Não inclua jogos ou BIOS protegidos por direitos autorais.

## Compilação local (com PSPSDK instalado)
```sh
make clean && make
```
